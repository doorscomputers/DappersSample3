﻿Public Class frmPasswordInput

    Private Sub txtPassword_KeyDown(sender As Object, e As KeyEventArgs) Handles txtPassword.KeyDown
        If e.KeyCode = Keys.Enter Then
            If Trim(txtPassword.Text.ToString) = "3256217235" Or Trim(txtPassword.Text.ToString) = "1" Then
                frmPOS.passcorrect = True
                Me.Close()
            Else
                frmPOS.passcorrect = False
                Me.Close()
            End If

        End If
    End Sub

    Private Sub frmPasswordInput_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        Me.Dispose()
    End Sub

    Private Sub frmPasswordInput_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.F4 Then
            ''~~~ Calling it and passing the name of the form to be displayed
            'Dim myObj As abcLockScreen = New abcLockScreen
            'myObj.LockSystemAndShow(Form2)
            e.Handled = True
        End If
    End Sub

    Private Sub frmPasswordInput_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtPassword.Focus()
    End Sub

    Private Sub frmPasswordInput_Click(sender As Object, e As EventArgs) Handles Me.Click
        txtPassword.Focus()
    End Sub

    Private Sub labLblPassword_Click(sender As Object, e As EventArgs) Handles labLblPassword.Click
        txtPassword.Focus()
    End Sub
End Class